import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import{FirstComponent} from './common/first/first.component';
import { SinglefileComponent } from './common/singlefile/singlefile.component';
import { Bind01Component } from './databind/bind01/bind01.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,FirstComponent, SinglefileComponent,Bind01Component],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'cdacapp';
}
