import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-singlefile',
  standalone: true,
  imports: [CommonModule],
  template: `
 
  <div class="col-md-6 m-0 card">
        
  <h1>Mr. {{name | uppercase}}</h1>
  <hr>
  <p>Address : {{address}}</p>
  <p>Age : {{age| currency : "INR"}}</p>
  <p>Object :{{obj |json}}</p>
  <p>Date of Birth : {{dob | date : 'EEEE, MMMM d, y'}}</p>
  </div>
  `,
  styles: `.card{color:red; background-color:lightyellow; padding: 2px}`
})
export class SinglefileComponent {
  name:string="Rajkumar";
  address:string="Delhi";
  age:number=25;
  dob:any=new Date("01/12/1976");
  obj:any={
    title:"Raj", movie:"Ravi"
  }
}
