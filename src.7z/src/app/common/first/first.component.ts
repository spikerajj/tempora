import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-first',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './first.component.html',
  styleUrl: './first.component.css'
})
export class FirstComponent {
  name:string="Rajkumar";
  address:string="Delhi";
  age:number=25;
  dob:any=new Date("01/12/1976");
  obj:any={
    title:"Raj", movie:"Ravi"
  }
}
