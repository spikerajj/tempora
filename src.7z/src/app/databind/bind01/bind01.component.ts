import { Component } from '@angular/core';

@Component({
  selector: 'app-bind01',
  standalone: true,
  imports: [],
  templateUrl: './bind01.component.html',
  styles: ``
})
export class Bind01Component {
  imgFile:string="/images/img.jpg";
data:string="Raj";
}
